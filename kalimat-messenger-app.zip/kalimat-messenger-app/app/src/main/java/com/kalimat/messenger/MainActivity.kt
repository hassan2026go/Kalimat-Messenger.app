package com.kalimat.messenger

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (auth.currentUser != null) showHome() else showWelcome()
    }

    private fun showWelcome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32, 32, 32, 32) }
        root.addView(TextView(this).apply { text = "Kalimat Messenger\\nرسائلك تبدأ من هنا"; textSize = 25f; gravity = Gravity.CENTER })
        val email = EditText(this).apply { hint = "البريد الإلكتروني"; inputType = 33 }
        val password = EditText(this).apply { hint = "كلمة المرور"; inputType = 129 }
        val login = Button(this).apply { text = "تسجيل الدخول" }
        val register = Button(this).apply { text = "إنشاء حساب" }
        root.addView(email, LinearLayout.LayoutParams(-1, -2)); root.addView(password, LinearLayout.LayoutParams(-1, -2)); root.addView(login); root.addView(register)
        setContentView(root)
        login.setOnClickListener {
            val e = email.text.toString().trim(); val p = password.text.toString()
            if (e.isBlank() || p.isBlank()) toast("أدخل البريد الإلكتروني وكلمة المرور")
            else auth.signInWithEmailAndPassword(e, p).addOnSuccessListener { showHome() }.addOnFailureListener { toast(it.localizedMessage ?: "تعذر تسجيل الدخول") }
        }
        register.setOnClickListener {
            val e = email.text.toString().trim(); val p = password.text.toString()
            if (e.isBlank() || p.length < 6) toast("أدخل بريدًا صحيحًا وكلمة مرور من 6 أحرف على الأقل")
            else auth.createUserWithEmailAndPassword(e, p).addOnSuccessListener { result ->
                val user = result.user ?: return@addOnSuccessListener
                val data = mapOf("uid" to user.uid, "email" to (user.email ?: ""), "createdAt" to System.currentTimeMillis())
                db.collection("users").document(user.uid).set(data).addOnSuccessListener { showHome() }.addOnFailureListener { toast("تم إنشاء الحساب، لكن تعذر حفظ الملف الشخصي") }
            }.addOnFailureListener { toast(it.localizedMessage ?: "تعذر إنشاء الحساب") }
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32, 32, 32, 32) }
        root.addView(TextView(this).apply { text = "أهلًا بك في Kalimat Messenger\\nتم تسجيل الدخول بنجاح. هذه نسخة البداية."; textSize = 22f; gravity = Gravity.CENTER })
        root.addView(Button(this).apply { text = "تسجيل الخروج"; setOnClickListener { auth.signOut(); showWelcome() } })
        setContentView(root)
    }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
}
