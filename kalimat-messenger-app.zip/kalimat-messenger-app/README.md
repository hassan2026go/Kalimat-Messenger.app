# Kalimat Messenger — Android starter

Starter Android project using Kotlin, Firebase Authentication and Cloud Firestore.

Before building:
1. Register a Firebase Android app with package name `com.kalimat.messenger`.
2. Place its `google-services.json` at `app/google-services.json`.
3. Enable Email/Password in Firebase Authentication.
4. Create Firestore and configure secure rules.

GitHub Actions builds a debug APK on pushes to `main` or via manual workflow dispatch. Download the artifact `kalimat-messenger-debug-apk`.

This starter currently provides account creation/login and a basic signed-in screen. Messaging, conversations, notifications and end-to-end encryption are not implemented yet. Configure secure Firestore rules before public use.
